﻿namespace Cognex_ImageSensor
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupbox_connection = new System.Windows.Forms.GroupBox();
            this.button_disconnect = new System.Windows.Forms.Button();
            this.button_connect = new System.Windows.Forms.Button();
            this.groupbox_devicelist = new System.Windows.Forms.GroupBox();
            this.listbox_devices = new System.Windows.Forms.ListBox();
            this.groupbox_image = new System.Windows.Forms.GroupBox();
            this.picturebox_image = new System.Windows.Forms.PictureBox();
            this.groupbox_selecteddevice = new System.Windows.Forms.GroupBox();
            this.label_deviceIP = new System.Windows.Forms.Label();
            this.textbox_deviceIP = new System.Windows.Forms.TextBox();
            this.groupbox_filesave = new System.Windows.Forms.GroupBox();
            this.button_browse = new System.Windows.Forms.Button();
            this.textbox_filename = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupbox_status = new System.Windows.Forms.GroupBox();
            this.textbox_status = new System.Windows.Forms.TextBox();
            this.groupbox_connection.SuspendLayout();
            this.groupbox_devicelist.SuspendLayout();
            this.groupbox_image.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picturebox_image)).BeginInit();
            this.groupbox_selecteddevice.SuspendLayout();
            this.groupbox_filesave.SuspendLayout();
            this.groupbox_status.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupbox_connection
            // 
            this.groupbox_connection.Controls.Add(this.button_disconnect);
            this.groupbox_connection.Controls.Add(this.button_connect);
            this.groupbox_connection.Location = new System.Drawing.Point(12, 12);
            this.groupbox_connection.Name = "groupbox_connection";
            this.groupbox_connection.Size = new System.Drawing.Size(216, 105);
            this.groupbox_connection.TabIndex = 0;
            this.groupbox_connection.TabStop = false;
            this.groupbox_connection.Text = "Connection";
            // 
            // button_disconnect
            // 
            this.button_disconnect.Location = new System.Drawing.Point(14, 62);
            this.button_disconnect.Name = "button_disconnect";
            this.button_disconnect.Size = new System.Drawing.Size(192, 28);
            this.button_disconnect.TabIndex = 2;
            this.button_disconnect.Text = "Disconnect";
            this.button_disconnect.UseVisualStyleBackColor = true;
            this.button_disconnect.Click += new System.EventHandler(this.button_disconnect_Click);
            // 
            // button_connect
            // 
            this.button_connect.Location = new System.Drawing.Point(13, 23);
            this.button_connect.Name = "button_connect";
            this.button_connect.Size = new System.Drawing.Size(193, 28);
            this.button_connect.TabIndex = 1;
            this.button_connect.Text = "Connect";
            this.button_connect.UseVisualStyleBackColor = true;
            this.button_connect.Click += new System.EventHandler(this.button_connect_Click);
            // 
            // groupbox_devicelist
            // 
            this.groupbox_devicelist.Controls.Add(this.listbox_devices);
            this.groupbox_devicelist.Location = new System.Drawing.Point(248, 12);
            this.groupbox_devicelist.Name = "groupbox_devicelist";
            this.groupbox_devicelist.Size = new System.Drawing.Size(212, 105);
            this.groupbox_devicelist.TabIndex = 1;
            this.groupbox_devicelist.TabStop = false;
            this.groupbox_devicelist.Text = "Device Discovery List";
            // 
            // listbox_devices
            // 
            this.listbox_devices.FormattingEnabled = true;
            this.listbox_devices.Location = new System.Drawing.Point(6, 16);
            this.listbox_devices.Name = "listbox_devices";
            this.listbox_devices.Size = new System.Drawing.Size(201, 82);
            this.listbox_devices.TabIndex = 0;
            this.listbox_devices.SelectedIndexChanged += new System.EventHandler(this.listbox_devices_SelectedIndexChanged);
            // 
            // groupbox_image
            // 
            this.groupbox_image.Controls.Add(this.picturebox_image);
            this.groupbox_image.Location = new System.Drawing.Point(469, 12);
            this.groupbox_image.Name = "groupbox_image";
            this.groupbox_image.Size = new System.Drawing.Size(144, 168);
            this.groupbox_image.TabIndex = 2;
            this.groupbox_image.TabStop = false;
            this.groupbox_image.Text = "Image";
            // 
            // picturebox_image
            // 
            this.picturebox_image.Location = new System.Drawing.Point(6, 16);
            this.picturebox_image.Name = "picturebox_image";
            this.picturebox_image.Size = new System.Drawing.Size(132, 143);
            this.picturebox_image.TabIndex = 0;
            this.picturebox_image.TabStop = false;
            // 
            // groupbox_selecteddevice
            // 
            this.groupbox_selecteddevice.Controls.Add(this.label_deviceIP);
            this.groupbox_selecteddevice.Controls.Add(this.textbox_deviceIP);
            this.groupbox_selecteddevice.Location = new System.Drawing.Point(12, 123);
            this.groupbox_selecteddevice.Name = "groupbox_selecteddevice";
            this.groupbox_selecteddevice.Size = new System.Drawing.Size(444, 57);
            this.groupbox_selecteddevice.TabIndex = 3;
            this.groupbox_selecteddevice.TabStop = false;
            this.groupbox_selecteddevice.Text = "Selected Device";
            // 
            // label_deviceIP
            // 
            this.label_deviceIP.AutoSize = true;
            this.label_deviceIP.Location = new System.Drawing.Point(27, 25);
            this.label_deviceIP.Name = "label_deviceIP";
            this.label_deviceIP.Size = new System.Drawing.Size(57, 13);
            this.label_deviceIP.TabIndex = 4;
            this.label_deviceIP.Text = "Device IP:";
            // 
            // textbox_deviceIP
            // 
            this.textbox_deviceIP.Location = new System.Drawing.Point(88, 22);
            this.textbox_deviceIP.Multiline = true;
            this.textbox_deviceIP.Name = "textbox_deviceIP";
            this.textbox_deviceIP.Size = new System.Drawing.Size(346, 21);
            this.textbox_deviceIP.TabIndex = 0;
            // 
            // groupbox_filesave
            // 
            this.groupbox_filesave.Controls.Add(this.button_browse);
            this.groupbox_filesave.Controls.Add(this.textbox_filename);
            this.groupbox_filesave.Controls.Add(this.label1);
            this.groupbox_filesave.Location = new System.Drawing.Point(11, 187);
            this.groupbox_filesave.Name = "groupbox_filesave";
            this.groupbox_filesave.Size = new System.Drawing.Size(602, 68);
            this.groupbox_filesave.TabIndex = 5;
            this.groupbox_filesave.TabStop = false;
            this.groupbox_filesave.Text = "File Save";
            // 
            // button_browse
            // 
            this.button_browse.Location = new System.Drawing.Point(549, 25);
            this.button_browse.Name = "button_browse";
            this.button_browse.Size = new System.Drawing.Size(35, 24);
            this.button_browse.TabIndex = 2;
            this.button_browse.Text = "...";
            this.button_browse.UseVisualStyleBackColor = true;
            this.button_browse.Click += new System.EventHandler(this.button_browse_Click);
            // 
            // textbox_filename
            // 
            this.textbox_filename.Location = new System.Drawing.Point(68, 25);
            this.textbox_filename.Multiline = true;
            this.textbox_filename.Name = "textbox_filename";
            this.textbox_filename.Size = new System.Drawing.Size(465, 25);
            this.textbox_filename.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "File Name:";
            // 
            // groupbox_status
            // 
            this.groupbox_status.Controls.Add(this.textbox_status);
            this.groupbox_status.Location = new System.Drawing.Point(12, 264);
            this.groupbox_status.Name = "groupbox_status";
            this.groupbox_status.Size = new System.Drawing.Size(601, 92);
            this.groupbox_status.TabIndex = 6;
            this.groupbox_status.TabStop = false;
            this.groupbox_status.Text = "Status";
            // 
            // textbox_status
            // 
            this.textbox_status.Location = new System.Drawing.Point(8, 16);
            this.textbox_status.Multiline = true;
            this.textbox_status.Name = "textbox_status";
            this.textbox_status.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textbox_status.Size = new System.Drawing.Size(587, 71);
            this.textbox_status.TabIndex = 0;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(622, 368);
            this.Controls.Add(this.groupbox_status);
            this.Controls.Add(this.groupbox_filesave);
            this.Controls.Add(this.groupbox_selecteddevice);
            this.Controls.Add(this.groupbox_image);
            this.Controls.Add(this.groupbox_devicelist);
            this.Controls.Add(this.groupbox_connection);
            this.Name = "MainForm";
            this.Text = "Cognex Image Sensor";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.groupbox_connection.ResumeLayout(false);
            this.groupbox_devicelist.ResumeLayout(false);
            this.groupbox_image.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picturebox_image)).EndInit();
            this.groupbox_selecteddevice.ResumeLayout(false);
            this.groupbox_selecteddevice.PerformLayout();
            this.groupbox_filesave.ResumeLayout(false);
            this.groupbox_filesave.PerformLayout();
            this.groupbox_status.ResumeLayout(false);
            this.groupbox_status.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupbox_connection;
        private System.Windows.Forms.Button button_disconnect;
        private System.Windows.Forms.Button button_connect;
        private System.Windows.Forms.GroupBox groupbox_devicelist;
        private System.Windows.Forms.ListBox listbox_devices;
        private System.Windows.Forms.GroupBox groupbox_image;
        private System.Windows.Forms.PictureBox picturebox_image;
        private System.Windows.Forms.GroupBox groupbox_selecteddevice;
        private System.Windows.Forms.Label label_deviceIP;
        private System.Windows.Forms.TextBox textbox_deviceIP;
        private System.Windows.Forms.GroupBox groupbox_filesave;
        private System.Windows.Forms.TextBox textbox_filename;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_browse;
        private System.Windows.Forms.GroupBox groupbox_status;
        private System.Windows.Forms.TextBox textbox_status;
    }
}

