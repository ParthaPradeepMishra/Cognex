﻿/*---------------------------------------------------------------------------------------------------------------------------------------------------
 * Program Name -  COGNEX IMAGE SENSOR - STANDALONE APPLICATION/TELEMETRY CODE (DATA ACQUISITION)
 * Summary      -  Reads the data from the Image Sensor/DataMan System based on Events and writes to a file as well as display the image in the form
 * Description  -  Uses Ethernet Discovery Mechanism to identify the list of devices connected to the Gateway/PC and connects to one of the Ethernet 
 *                 devices selected by user and based on events collects the data and writes to a file as well as displays in the UI
 ---------------------------------------------------------------------------------------------------------------------------------------------------*/
//Use System libraries
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.Threading;
using System.Xml;
using System.IO;

//Use the Cognex libraries
using Cognex.DataMan.SDK;
using Cognex.DataMan.SDK.Discovery;
using Cognex.DataMan.SDK.Utils;

namespace Cognex_ImageSensor
{
    public partial class MainForm : Form
    {
        //Initialization of the members of the Form class
        private ResultCollector _results;                          //Collect result components by Image ID which stores the complex packets arrived from sensor
        private EthSystemDiscoverer _ethSystemDiscoverer = null;   //Discoverers the Ethernet based DataMan System
        private SynchronizationContext _syncContext = null;        //Propagating a Synchronization contexts  
        private ISystemConnector _connector = null;                //A connector that can connect to DataMan System
        private DataManSystem _system = null;                      //Represent a DataMan system                
        private object _currentResultInfoSyncLock = new object();
        string filePath = "";                                      //Stores the absolute path of file where to save the data collected from sensor
        
        //Constructor of the main form
        public MainForm()
        {
            InitializeComponent();
        }

        //Event when the main form loads on running the application
        private void MainForm_Load(object sender, EventArgs e)
        {
            //On Loading of the form - disable/enable the buttons 
            textbox_deviceIP.Enabled = false;
            textbox_status.Enabled = false;
            textbox_filename.Enabled = false;
            button_disconnect.Enabled = false;
            button_connect.Enabled = false;

            // Create discoverers to discover ethernet systems
            _ethSystemDiscoverer = new EthSystemDiscoverer();

            // Subscribe to the system discoved event
            _ethSystemDiscoverer.SystemDiscovered += new EthSystemDiscoverer.SystemDiscoveredHandler(OnEthSystemDiscovered);

            // Ask the discoverers to start discovering systems
            _ethSystemDiscoverer.Discover();
        }
        
        #region Device Discovery Events

        //Event when a Ethernet system connected to a Gateway/PC is detected
        private void OnEthSystemDiscovered(EthSystemDiscoverer.SystemInfo systemInfo)
        {
            _syncContext.Post(
                new SendOrPostCallback(
                    delegate
                    {
                        //If any Ethernet system is discovered, add the system info to the list
                        listbox_devices.Items.Add(systemInfo);
                    }),
                    null);
        }

        #endregion

        //Event for changing the selected device from Ethernet Device Discovery List
        private void listbox_devices_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Check if the selected device in list is valid
            if (listbox_devices.SelectedIndex != -1 && listbox_devices.Items.Count > listbox_devices.SelectedIndex)
            {
                //Stores the selected device from Discovery mechanism into system_info variable
                var system_info = listbox_devices.Items[listbox_devices.SelectedIndex];

                //If the device is of type Discovered Ethernet device 
                if (system_info is EthSystemDiscoverer.SystemInfo)
                {
                    //Store the system info into the System Information of the Ethernet Discovered System
                    EthSystemDiscoverer.SystemInfo eth_system_info = system_info as EthSystemDiscoverer.SystemInfo;

                    //Display the IP Address of the device being selected in the Drop-down list in Device IP List
                    textbox_deviceIP.Text = eth_system_info.IPAddress.ToString();
                }

                //Enable the connect button after selecting a device from the list - if the filename to be saved specified
                if (textbox_filename.Text != "" || textbox_filename.Text != null)
                    button_connect.Enabled = (_connector != null && _connector.State == ConnectionState.Disconnected) || (_connector == null);
            }

            //If the selected index in device list is invalid
            else
                button_connect.Enabled = false;  //Disable the connect button
       }


        //Event for connect button clicked by the user
        private void button_connect_Click(object sender, EventArgs e)
        {
            //If the selected device is invalid or no device selected
            if (listbox_devices.SelectedIndex == -1 || listbox_devices.SelectedIndex >= listbox_devices.Items.Count)
                return;

            //If connected - then disable the connected button
            button_connect.Enabled = false;

            try
            {
                //Store the selected Discovery device into system info variable
                var system_info = listbox_devices.Items[listbox_devices.SelectedIndex];

                //If the system info is of type Discovered Ethernet systems
                if (system_info is EthSystemDiscoverer.SystemInfo)
                {
                   //Stores the details of system info in Ethernet System Discoverer
                    EthSystemDiscoverer.SystemInfo eth_system_info = system_info as EthSystemDiscoverer.SystemInfo;
                    
                    //Create an instance of Ethernet System Connector using IP Address and Port Number
                    EthSystemConnector conn = new EthSystemConnector(eth_system_info.IPAddress, eth_system_info.Port);

                    //Specify the username and password of Ethernet Connector
                    conn.UserName = "admin";
                    conn.Password = "admin";

                    //Initialize the ISystemConnector as Ethernet Connector
                    _connector = conn;
                }

                //Initialise the DataMan instance through ISystemConnector connector
                _system = new DataManSystem(_connector);

                //Default timeout for DataMan system
                _system.DefaultTimeout = 5000;

                // Subscribe to events that are signalled when the system is connected / disconnected.
                _system.SystemConnected += new SystemConnectedHandler(OnSystemConnected);
                _system.SystemDisconnected += new SystemDisconnectedHandler(OnSystemDisconnected);
                _system.SystemWentOnline += new SystemWentOnlineHandler(OnSystemWentOnline);
                _system.SystemWentOffline += new SystemWentOfflineHandler(OnSystemWentOffline);

                // Subscribe to events that are signalled when the device sends auto-responses.
                ResultTypes requested_result_types = ResultTypes.ReadXml | ResultTypes.Image | ResultTypes.ImageGraphics;
                _results = new ResultCollector(_system, requested_result_types);
                _results.ComplexResultArrived += Results_ComplexResultArrived;
                _results.PartialResultDropped += Results_PartialResultDropped;

                //Connect to the DataMan system
                _system.Connect();

                //Set the result types that is collected from the DataMan System
                _system.SetResultTypes(requested_result_types);
            }
        

            /* Exception handling when an error occurs during tasks such as - 
             * 1. Connection to a DataMan system fails 
             * 2. Registering the events for Complex Results arrival or Partial result
             * 3. Creating an instance of Ethernet System connector for establishing ethernet connection to DataMan system */
              
            catch (Exception ex)
            {
                //Unsubscribe the System online, offline event handler and display the error message
                CleanupConnection();
                textbox_status.Text = "Error: " + ex.ToString();
                
                //Any error - occurs then enable the connect button and disable the disconnect button
                button_connect.Enabled = true;
                button_disconnect.Enabled = false;
            }
        }

            //Event for complex result arrival from DataMan system
            void Results_ComplexResultArrived(object sender, ResultInfo e)
    		{
			_syncContext.Post(
				delegate
				{
                    //If complex results arrived, save the result to a file and display the result in picture box of form
                    SaveResultToFile(e);
					ShowResult(e);

				},
				null);
	    	}


        //Write the complex packet data to a file
        //Complex Packet contains data such as Timestamp, Image ID, Result ID, Read String, Result Image Graphics, Result XML Result and list of it
        private void SaveResultToFile(ResultInfo result)
        {
            //Write the complex packet components to a file
            File.AppendAllText(filePath, "\n");
            File.AppendAllText(filePath, "TimeStamp = " +result.ResultArrivedAt.ToString("yyyyMMddHHmmss") +",");
            File.AppendAllText(filePath, " Image ID = "+result.ImageId.ToString() + ",");
            File.AppendAllText(filePath, " Result ID = "+result.ResultId.ToString() + ",");
            File.AppendAllText(filePath, " Read String = "+result.ReadString + ",");
            File.AppendAllText(filePath, " Result Image Graphics = "+result.ImageGraphics + ",");
            File.AppendAllText(filePath, " Result XML Result = "+result.XmlResult);

            //If there are no sub-results to write, then return
            if ((result.SubResults == null) || (result.SubResults.Count == 0))
            {
                return;
            }

            //Recursively write the contents of each subresults collection in the complex packet
            foreach (ResultInfo rinfo in result.SubResults)
            {
                SaveResultToFile(rinfo);
            }
        }

        //This method is called to read the String components arrived from DataMan System from XML if it is null/empty       
        private string GetReadStringFromResultXml(string resultXml)
        {
            try
            {
                XmlDocument doc = new XmlDocument();

                //Load the XML result component arrived from the DataMan system
                doc.LoadXml(resultXml);

                //Select a single node of the XML
                XmlNode full_string_node = doc.SelectSingleNode("result/general/full_string");

                //If the selected node is not empty, return the inner text of the selected node
                if (full_string_node != null)
                {
                    XmlAttribute encoding = full_string_node.Attributes["encoding"];
                    if (encoding != null && encoding.InnerText == "base64")
                    {
                        byte[] code = Convert.FromBase64String(full_string_node.InnerText);
                        return _system.Encoding.GetString(code, 0, code.Length);
                    }

                    return full_string_node.InnerText;
                }
            }

            //Error occurs while parsing or loading the XML result component
            catch(Exception ex)
            {
                //Display the error message in the status textbox
                textbox_status.Text = "Error:" + ex.Message;
            }

            return "";
        }


        //Displays the result collector components (complex packets) arrrived from DataMan system as image in Picture box of form
        private void ShowResult(ResultInfo e)
        {
            //Maintain a list of images and image graphics arrived
            List<Image> images = new List<Image>();
            List<string> image_graphics = new List<string>();
            string read_result = null;

            // Take a reference or copy values from the locked result info object. This is done
            // so that the lock is used only for a short period of time.
            lock (_currentResultInfoSyncLock)
            {
                //If the string component arrived from DatMan is not null then consider that value else get the result from xml
                read_result = !String.IsNullOrEmpty(e.ReadString) ? e.ReadString : GetReadStringFromResultXml(e.XmlResult);

                //If the components arrived from DataMan is not null, then add the components to respective lists or collections
                if (e.Image != null)
                    images.Add(e.Image);

                if (e.ImageGraphics != null)
                    image_graphics.Add(e.ImageGraphics);

                if (e.SubResults != null)
                {
                    foreach (var item in e.SubResults)
                    {
                        if (item.Image != null)
                            images.Add(item.Image);

                        if (item.ImageGraphics != null)
                            image_graphics.Add(item.ImageGraphics);
                    }
                }
            }

            //Displays the complex packet results arrived in status textbox
            textbox_status.Text="Complex result arrived : resultId = " + e.ResultId + ", read result = " + read_result;

            if (images.Count > 0)
            {
                Image first_image = images[0];

                //Resize the image data into bitmap and fit it into the picturebox of form
                Size image_size = Gui.FitImageInControl(first_image.Size, picturebox_image.Size);
                Image fitted_image = Gui.ResizeImageToBitmap(first_image, image_size);

                //Creating a Graphics object from Image and use the Image Graphics string data to render the Image in Paint surface
                if (image_graphics.Count > 0)
                {
                    using (Graphics g = Graphics.FromImage(fitted_image))
                    {
                        foreach (var graphics in image_graphics)
                        {
                            ResultGraphics rg = GraphicsResultParser.Parse(graphics, new Rectangle(0, 0, image_size.Width, image_size.Height));
                            ResultGraphicsRenderer.PaintResults(g, rg);
                        }
                    }
                }

                //If there is another image in picture box of form, then release/dispose it
                if (picturebox_image.Image != null)
                    picturebox_image.Image.Dispose();

                //else display the Image and invalidate it which causes the control to be redrawn
                picturebox_image.Image = fitted_image;
                picturebox_image.Invalidate();
            }

            //Displays the read result in the status
            if (read_result != null)
                textbox_status.Text = read_result;
        }

         #region Dropped Packets

        //Identify the Result components which has not arrived and has null value/dropped packets
         void ReportDroppedResult(ResultInfo e)
		{
            //List of string that maintains/identifies the components that was dropped along with its Result ID
			List<string> dropped = new List<string>();

			if (e.Image != null) dropped.Add(String.Format("image (ResultId={0}, ImageId={1})", e.ResultId, e.ImageId));
			if (e.ImageGraphics != null) dropped.Add(String.Format("graphics (ResultId={0}, ImageId={1})", e.ResultId, e.ImageId));
			if (e.ReadString != null) dropped.Add(String.Format("read string (ResultId={0})", e.ResultId));
			if (e.XmlResult != null) dropped.Add(String.Format("xml result (ResultId={0})", e.ResultId));

			textbox_status.Text="Partial results dropped: " + String.Join(", ", dropped.ToArray());
		}


        //Event for the arrival of the Partial Result from Sensor/DataMan remote system
        void Results_PartialResultDropped(object sender, ResultInfo e)
		{
			_syncContext.Post(
				delegate
				{
                    //Check for partial packets arrival in sub-results component of Result Collector class
					if (e.SubResults != null)
					{
						foreach (var sub_result in e.SubResults)
						{
							ReportDroppedResult(sub_result);
						}
					}

                    //Check for partial packets arrival in components of Result collector class
					ReportDroppedResult(e);
				},
				null);
		}

        #endregion

        #region Auxilliary Methods

        //CleanupConnection() method to unsubscribe for all events and make DataMan system and Connector to Ethernet System to null
        private void CleanupConnection()
		{
            //Unsubscribe for all connection events
			if (null != _system)
			{
				_system.SystemConnected -= OnSystemConnected;
				_system.SystemDisconnected -= OnSystemDisconnected;
				_system.SystemWentOnline -= OnSystemWentOnline;
				_system.SystemWentOffline -= OnSystemWentOffline;
			}

            //Initialize the Ethernet connector and DataMan system to null
			_connector = null;
			_system = null;
		}

        #endregion

        #region Device Events

        //Event triggered when the connection to a remote DataMan system is successful
		private void OnSystemConnected(object sender, EventArgs args)
		{
			_syncContext.Post(
				delegate
				{
                    button_connect.Enabled = false;
                    button_disconnect.Enabled = true;
                    textbox_status.Text="System connected";
				},
				null);
		}

        //Event triggered when connection to a remote DataMan is disconnected
		private void OnSystemDisconnected(object sender, EventArgs args)
		{
			_syncContext.Post(
				delegate
				{
					textbox_status.Text="System disconnected";
     				button_connect.Enabled = true;
					button_disconnect.Enabled = false;
				},
				null);
		}

        //Event triggered when DataMan system went online
		private void OnSystemWentOnline(object sender, EventArgs args)
		{
			_syncContext.Post(
				delegate
				{
					textbox_status.Text="System went online";
				},
				null);
		}

        //Event triggered when DataMan system went offline
		private void OnSystemWentOffline(object sender, EventArgs args)
		{
			_syncContext.Post(
				delegate
				{
					textbox_status.Text="System went offline";
				},
				null);
		}

		#endregion

        //Event triggered when user clicks the disconnect button
        private void button_disconnect_Click(object sender, EventArgs e)
        {       
            if (_system == null || _system.State != ConnectionState.Connected)
				return;

            //Make the Disconnect button disabled
            button_disconnect.Enabled = false;

            //Disconnect the system and clean up connection and clear cache results
            _system.Disconnect();
            CleanupConnection();
			_results.ClearCachedResults();
			_results = null;
        }
               
        //Event for clicking of Browse button by user to specify the location where to save the file
        private void button_browse_Click(object sender, EventArgs e)
        {
            //Open the save file Dialog Box and specify the title, filter and default extension for file
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();     
            saveFileDialog1.InitialDirectory = @"C:\";
            saveFileDialog1.Title = "Save Log Files";
            saveFileDialog1.CheckPathExists = true;
            saveFileDialog1.DefaultExt = "log";
            saveFileDialog1.Filter = "Log files (*.log)|*.log";
            saveFileDialog1.FilterIndex = 1;
            saveFileDialog1.RestoreDirectory = true;     
 
            //On Clicking OK button, stores the filepath and displays filename in status textbox
            if(saveFileDialog1.ShowDialog() == DialogResult.OK)
               {
                 filePath=saveFileDialog1.FileName;
                 string []sub_string=filePath.Split('\\');
                 textbox_filename.Text = sub_string[sub_string.Length-1];
               }
        }
       

    }

    }
